from flask import Flask, render_template, request
import joblib
import pandas as pd

# ✅ 1. Create Flask app first
app = Flask(__name__)

# ✅ 2. Load your model
model = joblib.load("reactorguard_ai_model_pipeline.pkl")

# ✅ 3. Define routes after app is created
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get user input from the form
        data = {
            'Country/Area': request.form['Country/Area'],
            'Project Name': request.form['Project Name'],
            'Unit Name': request.form['Unit Name'],
            'Capacity (MW)': float(request.form['Capacity (MW)']),
            'Reactor Type': request.form['Reactor Type'],
            'Model': request.form['Model'],
            'Latitude': float(request.form['Latitude']),
            'Longitude': float(request.form['Longitude']),
            'City': request.form['City'],
            'State/Province': request.form['State/Province'],
            'Region': request.form['Region'],
            'Wiki URL': request.form['Wiki URL']
        }

        # Convert to DataFrame
        input_df = pd.DataFrame([data])

        # Optional: Manual override for testing abnormal condition
        manual_override = request.form.get('Abnormal', 'off')
        if manual_override == 'on':
            result = "⚠️ Abnormal Condition (Simulated)"
        else:
            prediction = model.predict(input_df)[0]
            result = "✅ Normal Operation" if prediction == 0 else "⚠️ Abnormal Condition"

        return render_template('index.html', prediction=result)

    except Exception as e:
        return render_template('index.html', prediction=f"Error: {str(e)}")

# ✅ 4. Run the app
if __name__ == "__main__":
    app.run(debug=True)
